class ShoesModel {
  String? image;

  ShoesModel({this.image});
}
